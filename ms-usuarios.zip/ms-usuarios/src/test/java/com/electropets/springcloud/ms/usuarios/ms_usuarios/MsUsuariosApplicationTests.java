package com.electropets.springcloud.ms.usuarios.ms_usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
